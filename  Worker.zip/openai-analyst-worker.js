// NFL Market Dashboard V0.6.2 — secure AI analyst endpoint
// Cloudflare Worker. Secret: OPENAI_API_KEY. Optional: AI_SHARED_SECRET.
const VERSION='dcc-ai-worker-v0.6.2-diag1';
const schema={type:'object',additionalProperties:false,properties:{model:{type:'string'},promptVersion:{type:'string'},reviewedAt:{type:'string'},slateSummary:{type:'string'},audit:{type:'string'},challenge:{type:'string'},sources:{type:'array',items:{type:'object',additionalProperties:false,properties:{title:{type:'string'},url:{type:'string'}},required:['title','url']}},bets:{type:'array',items:{type:'object',additionalProperties:false,properties:{gameId:{type:'string'},decision:{type:'string',enum:['BET','LEAN','PASS']},marketType:{type:'string',enum:['spread','total']},side:{type:'string',enum:['home','away','over','under']},confidence:{type:'number'},fairLine:{type:'string'},edge:{type:'string'},reasons:{type:'array',items:{type:'string'}},risks:{type:'array',items:{type:'string'}},explanation:{type:'string'}},required:['gameId','decision','marketType','side','confidence','fairLine','edge','reasons','risks','explanation']}}},required:['model','promptVersion','reviewedAt','slateSummary','audit','challenge','sources','bets']};
function cors(origin){return {'Access-Control-Allow-Origin':origin||'*','Access-Control-Allow-Headers':'Content-Type, X-DCC-Secret','Access-Control-Allow-Methods':'GET, POST, OPTIONS','Content-Type':'application/json','Cache-Control':'no-store'}}
export default{async fetch(request,env){const origin=request.headers.get('Origin')||'*',headers=cors(origin);if(request.method==='OPTIONS')return new Response('',{status:204,headers});if(env.AI_SHARED_SECRET&&(request.headers.get('X-DCC-Secret')||'')!==env.AI_SHARED_SECRET)return new Response(JSON.stringify({error:'Unauthorized'}),{status:401,headers});if(request.method==='GET'){
  const url=new URL(request.url);
  if(url.searchParams.get('diagnostic')==='1'){
    if(!env.OPENAI_API_KEY)return new Response(JSON.stringify({ok:false,version:VERSION,stage:'configuration',error:'OPENAI_API_KEY is not configured'}),{status:500,headers});
    try{
      const dr=await fetch('https://api.openai.com/v1/responses',{
        method:'POST',
        headers:{Authorization:`Bearer ${env.OPENAI_API_KEY}`,'Content-Type':'application/json'},
        body:JSON.stringify({model:'gpt-5.6-sol',input:'Reply with exactly: OK',max_output_tokens:16})
      });
      const draw=await dr.text();
      let dj={};try{dj=JSON.parse(draw)}catch{}
      if(!dr.ok){
        const oe=dj?.error||{};
        return new Response(JSON.stringify({
          ok:false,version:VERSION,stage:'openai_request',openaiStatus:dr.status,
          errorType:oe.type||null,errorCode:oe.code||null,
          message:(oe.message||'OpenAI request failed').slice(0,500)
        }),{status:dr.status,headers});
      }
      return new Response(JSON.stringify({
        ok:true,version:VERSION,stage:'openai_request',openaiStatus:dr.status,
        model:dj.model||'gpt-5.6-sol',message:'OpenAI connectivity test passed'
      }),{status:200,headers});
    }catch(e){
      return new Response(JSON.stringify({ok:false,version:VERSION,stage:'network',message:String(e?.message||e).slice(0,500)}),{status:502,headers});
    }
  }
  return new Response(JSON.stringify({ok:true,version:VERSION,openaiConfigured:!!env.OPENAI_API_KEY,diagnostic:'Append ?diagnostic=1 to run a safe OpenAI connectivity test'}),{status:200,headers});
}if(request.method!=='POST')return new Response(JSON.stringify({error:'POST only'}),{status:405,headers});if(!env.OPENAI_API_KEY)return new Response(JSON.stringify({error:'OPENAI_API_KEY is not configured on the server'}),{status:500,headers});let body;try{body=await request.json()}catch{return new Response(JSON.stringify({error:'Invalid JSON'}),{status:400,headers})}const snapshot=body?.snapshot;if(!snapshot?.games?.length)return new Response(JSON.stringify({error:'Snapshot is missing games'}),{status:400,headers});
const system=`You are the Chief Analyst for a personal NFL market-analysis terminal. Analyze spreads and totals using the supplied immutable market snapshot and current web research when enabled. NON-NEGOTIABLE: Never invent lines, prices, injuries, weather, statistics, or sources. DraftKings is the user’s only actionable sportsbook. The client—not you—selects and verifies the final DraftKings line/price. Other books are context only. For each game choose only marketType (spread|total) and side (home|away|over|under), plus BET/LEAN/PASS. For PASS still return a syntactically valid marketType/side but it will not be acted on. Challenge your first impression and explicitly consider reasons not to bet. BET only with meaningful evidence; LEAN is not a Best Bet; PASS is always acceptable. Confidence measures evidence quality, not outcome certainty. Review the full slate and do not force bets. No player props.`;
const user=`Review the slate and return exactly one structured decision per game. Current snapshot JSON:\n${JSON.stringify(snapshot)}`;
const req={model:body.model||'gpt-5.6-sol',reasoning:{effort:'high'},tools:body.webResearch===false?[]:[{type:'web_search',search_context_size:'low'}],input:[{role:'system',content:system},{role:'user',content:user}],text:{format:{type:'json_schema',name:'nfl_market_analysis',strict:true,schema}}};
const r=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{Authorization:`Bearer ${env.OPENAI_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify(req)});const raw=await r.text();if(!r.ok){let ej={};try{ej=JSON.parse(raw)}catch{}const oe=ej?.error||{};return new Response(JSON.stringify({error:`OpenAI HTTP ${r.status}`,stage:'openai_request',openaiStatus:r.status,errorType:oe.type||null,errorCode:oe.code||null,message:(oe.message||'OpenAI request failed').slice(0,500),workerVersion:VERSION}),{status:502,headers});}let response;try{response=JSON.parse(raw)}catch{return new Response(JSON.stringify({error:'OpenAI returned invalid JSON'}),{status:502,headers})}let text=response.output_text;if(!text&&Array.isArray(response.output)){for(const o of response.output)for(const c of o.content||[])if(c.type==='output_text'&&c.text)text=c.text}if(!text)return new Response(JSON.stringify({error:'OpenAI response contained no structured output'}),{status:502,headers});let analysis;try{analysis=JSON.parse(text)}catch{return new Response(JSON.stringify({error:'Structured output could not be parsed'}),{status:502,headers})}analysis.model=body.model||analysis.model||'gpt-5.6-sol';analysis.promptVersion='dcc-chief-analyst-v2.0';analysis.reviewedAt=new Date().toISOString();analysis.validated=true;return new Response(JSON.stringify({analysis}),{status:200,headers})}};
