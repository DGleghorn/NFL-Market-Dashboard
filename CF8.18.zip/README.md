# Degenerate’s Advisor v0.8.18 Cloudflare Worker

Preserves the existing Workers AI binding and v0.8.17 ParlayAPI prop mapping.

New safe diagnostic:
GET /binding-check

It returns boolean presence only for AI, PROP_API_KEY and AI_SHARED_SECRET. No secret values are exposed.

Important: Cloudflare secrets remain runtime-managed. Do not put PROP_API_KEY in wrangler.jsonc or source control.
